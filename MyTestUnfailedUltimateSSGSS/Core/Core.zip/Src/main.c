/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "stdlib.h"
#define ARM_MATH_CM4 
#include "arm_math.h"

#include "MCUFRIEND_kbv.h"
#include "math.h"
#include "ball.h"

//#include "MCUFRIEND_kbv.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SNR_THRESHOLD_F32    75.0f
#if defined(ARM_MATH_MVEF) && !defined(ARM_MATH_AUTOVECTORIZE)
/* Must be a multiple of 16 */
#define NUM_TAPS_ARRAY_SIZE              32
#else
#define NUM_TAPS_ARRAY_SIZE              29
#endif
#define NUM_TAPS              29


#define TEST_LENGTH_SAMPLES  320


#define BLOCK_SIZE            1
#if defined(ARM_MATH_MVEF) && !defined(ARM_MATH_AUTOVECTORIZE)
static float32_t firStateF32[2 * BLOCK_SIZE + NUM_TAPS - 1];
#else
static float32_t firStateF32[BLOCK_SIZE + NUM_TAPS - 1];
#endif 

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

///////////////////////LAB4 VARIABLES
int hour = 0;
int min = 0;
int sec = 0;
int tauxRafraichissement = 200; //en ms
volatile int milli = 0;
volatile int token = 1;

///////////////////////LAB6 VARIABLES
float tab_value[256]; 
float tab_value_30inputs[30]; 
float tab_output[256]; 
float FFT_value[256];
float abs_value[128];
uint32_t blockSize = BLOCK_SIZE;
uint32_t numBlocks = 256;

///////////////////////LAB7 VARIABLES
volatile int flag_done = -1;
volatile int current_state = 0;
volatile int key = 1;		
volatile float tempsDePesee = 0;
volatile int local_time = 0;
const float pi = 3.14159265358979323846;

volatile float positionXball; 
volatile float positionYball; //Ball
volatile float positionYball_initiale;
volatile float positionXball_initiale;
float positionXpig;
float positionYpig;  // Pig
volatile float vx ;	//is related to y coordinate for LCD
volatile float vy ;	//is related to x coordinate for LCD	
volatile float ay = -0.01;
volatile int compteur = 0;		
volatile int compteur2 = 0;		
float v_initial;	
volatile int flag_state = 0;
volatile int compteur3 = 0;		


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

#define SUPPORT_ECRAN_1


void selectRow (int r) 
{
	if (r==1) HAL_GPIO_WritePin(R1_GPIO_Port, R1_Pin, GPIO_PIN_RESET);
	else HAL_GPIO_WritePin(R1_GPIO_Port, R1_Pin, GPIO_PIN_SET);
	if (r==2) HAL_GPIO_WritePin(R2_GPIO_Port, R2_Pin, GPIO_PIN_RESET);
	else HAL_GPIO_WritePin(R2_GPIO_Port, R2_Pin, GPIO_PIN_SET);
	if (r==3) HAL_GPIO_WritePin(R3_GPIO_Port, R3_Pin, GPIO_PIN_RESET);
	else HAL_GPIO_WritePin(R3_GPIO_Port, R3_Pin, GPIO_PIN_SET);
	if (r==4) HAL_GPIO_WritePin(R4_GPIO_Port, R4_Pin, GPIO_PIN_RESET);
	else HAL_GPIO_WritePin(R4_GPIO_Port, R4_Pin, GPIO_PIN_SET);
}

int readCol() 
{
	int result = 0;
	if (HAL_GPIO_ReadPin(C1_GPIO_Port, C1_Pin) == GPIO_PIN_RESET) result += 1;
	if (HAL_GPIO_ReadPin(C2_GPIO_Port, C2_Pin) == GPIO_PIN_RESET) result += 2;
	if (HAL_GPIO_ReadPin(C3_GPIO_Port, C3_Pin) == GPIO_PIN_RESET) result += 4;
	if (HAL_GPIO_ReadPin(C4_GPIO_Port, C4_Pin) == GPIO_PIN_RESET) result += 8;
	return result;
}

//void HAL_SYSTICK_Callback(void) 
//{
//	milli++;
//	if (milli < tauxRafraichissement) return;
//	milli=0; 
//	token = 1;	
//	sec++;
//	if (sec < 60) return;
//	sec = 0; 
//	min++;
//	if (min < 60) return;
//	min = 0; hour++;
//	if (hour < 24) return;
//	hour = 0;
//	return;
//}

void HAL_SYSTICK_Callback(void) 
{
	local_time++;	
	key = HAL_GPIO_ReadPin(C4_GPIO_Port, C4_Pin);
	//Determiner temps de pes�e
	switch (current_state) 
	{
		case 0: //State X
			if (key != 1) 
			{
				//key is pressed, go to state Y
				current_state=1;
				
			}
			break;
		case 1: //State Y
			if (key == 1) 
			{
				//key is released, go to state Z
				compteur2++;
				current_state=2;
			}
			compteur3++;
			break;
		case 2: //State Z
				compteur++;
			break;
	}	
}


int keyPressed() 
{
	int rowPos=1; //Current row positiom
	int rowValue; //Value read from the current row
	for (rowPos=1; rowPos <= 4; rowPos++) 
	{
		selectRow(rowPos);
		HAL_Delay(10);
//		while (token2 == 0); //attendre 10ms
//		token2 = 0;
		rowValue=readCol();
		if (rowValue != 0) 
		{ // a key is pressed
			int result = 4*(rowPos-1);
			while (!(rowValue & 1)) 
			{ // test if bit #0 is false
				result++;
				rowValue>>=1;
			}
			while (readCol() != 0); // key no more pressed
			return result;
		}
	}
	return -1;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
	// LCD initialization
	LCD_Begin();
	HAL_Delay(20);
	LCD_SetRotation(0);
	LCD_FillScreen(BLACK);
	//LCD_DrawFastHLine(0, 160, 240, YELLOW);
//	LCD_DrawCircle(N/2, N/2, 15, WHITE);
	//LCD_DrawRect(20, 40, 202, 240, RED);
//	LCD_Printf("! Hello !");
	
//placing elements :
	//ball is 10pixels radius 3D ball (use draw_ball_3d from lab5 and make it red!)
	//Place ball at position (x,y) NB : use float type for y and i guess unsigned int type for x?
	//place wall in middle of screen : coordinate x is wall's height, it is 120pixels | coordinate y is 160 (wall in the middle of screen)
	//pig is 20pixel radius empty circle (use LCD_DrawCircle and make it green!)
	//place pig in random x/y values in pixels AFTER the wall in the middle of screen (i.e. pig's position is x between 0 and 240px and y between 160 and 320px)
	positionXball = 0; 
	positionYball = 0; //Ball
	positionYball_initiale = 0;
	positionXball_initiale = 0;
	positionXpig = rand()%240;  
	positionYpig = 200 + rand()%120;  
	LCD_FillRect(0,150,120,20,WHITE);  // Mur
	LCD_FillCircle(positionXball , positionYball, 10, RED);   //Ball
	LCD_FillCircle(positionXpig , positionYpig, 20, GREEN);   // Pig

//setting initial conditions (speed and angle) :
//	key = keyPressed();	
//	if (current_state==1)
//	{
//		//bouton a �t� appuy�
//		tempsDePesee=local_time;				
//	}
//	if (current_state==2)
//	{
//		//bouton a �t� rel�ch�
//		tempsDePesee = local_time - tempsDePesee;				
//	}
						
//	v_initial = 1;//(float) tempsDePesee/2000.0;//tempsDePesee;		
	//ADC reading for angle
	float scale = ((pi/180.0)*90.0)/4096.0;
	HAL_ADC_Start(&hadc1); 
	HAL_ADC_PollForConversion(&hadc1,100);
	float angle = HAL_ADC_GetValue(&hadc1)*scale; 
	//v_initial = tempsDePesee
	//angle = ??			(read potenitometer, angle is certainly between -90 and 90 degrees)
//	vx = cos(angle)*v_initial;	//is related to y coordinate for LCD
//	vy = sin(angle)*v_initial;	//is related to x coordinate for LCD	
//	ay = -0.01;	
	//Afficher angle � l'�cran
	LCD_DrawLine(0, 0, 100*sin(angle), 100*cos(angle), WHITE);
	
	//Start TIMer 2
	HAL_TIM_Base_Start_IT(&htim2);	

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		printf("Changed to state : %i and compteur3 = %d and key = %d\r\n",current_state, compteur3, key);
		if (flag_done == -1)
		{
		//setting initial conditions (speed and angle) :
//			key = keyPressed();
			if (current_state==1)
			{
				//bouton a �t� appuy�
//				tempsDePesee=local_time;
			printf("Changed to state : %i and compteur3 = %d and key = %d\r\n",current_state, compteur3, key);
			}
			if (current_state==2)
			{
				//bouton a �t� rel�ch�
//				printf("Changed to state : %i and compteur3 = %d and key = %d\r\n",current_state, compteur3, key);
				tempsDePesee = compteur3;//local_time - tempsDePesee;		
				v_initial = (float) tempsDePesee/1000;//tempsDePesee;
				flag_state=1;
				printf("Changed to state : %i and compteur3 = %d and key = %d and v_initial = %f\r\n",current_state, compteur3, key, v_initial);
			}
						
			//ADC reading for angle
			float scale = ((pi/180.0)*90.0)/4096.0;
			HAL_ADC_Start(&hadc1); 
			HAL_ADC_PollForConversion(&hadc1,100);
			float angle = HAL_ADC_GetValue(&hadc1)*scale; 
			
			//v_initial = tempsDePesee
			//angle = ??			(read potenitometer, angle is certainly between -90 and 90 degrees)
			if((compteur2==1) && (flag_state==1))
			{
				vx = cos(angle)*v_initial;	//is related to y coordinate for LCD
				vy = sin(angle)*v_initial;	//is related to x coordinate for LCD	
				compteur2++;
			}
//			ay = -0.01;	
			//Afficher angle � l'�cran
			LCD_DrawLine(0, 0, 100*sin(angle), 100*cos(angle), WHITE);
			if(((key == 1)&&(compteur != 0 )&&(compteur2 > 1) ) && (flag_state==1))
			{
				
//				if( (positionXball_initiale-positionXball)*(positionXball_initiale-positionXball)
//					+(positionYball_initiale-positionYball)*(positionYball_initiale-positionYball)
				
				LCD_FillCircle(positionXball_initiale, positionYball_initiale, 15, BLACK);   //Ball
				LCD_FillCircle(positionXball , positionYball, 10, RED);   //Ball
				positionYball_initiale=positionYball;
				positionXball_initiale=positionXball;

			}
		}
		if (flag_done == 1)
		{
			//user has won!!!
			LCD_FillScreen(GREEN);
			while(1);
		};
		if (flag_done == 2)
		{
			//user has lost!!!
			LCD_FillScreen(RED);
			while(1);
		};
		
    /* USER CODE END WHILE */
		
		//LAB 6

		
	//moving elements :
		//Use interrupt for moving logic
		//use interrupt routine to notify program when 10ms have past
		//Don't increment x speed (vx = vx_initial;)
		//declare vy as float
		//increment y speed (vy = vy + ay  where ay is typically to be set later, start with ay = -0.01)
		
	//Verifying if user has won :
		//if position(ball) == position(pig) then WIN and stop ball movement
		//if position(ball) == position(wall) then LOOSE
		//if position(ball) == position(any_edge_of_the_screen) then LOOSE
		
		
		
		
		//exp�rience 2
//		int x;
//		float scale = 160.0/4096.0;
//		for (x=0;x<256;x++) 
//		{
//			while (flag_done == 0); // Wait for interrupt
//			flag_done = 0; // Reset flag_done
//			HAL_ADC_PollForConversion(&hadc1,100);
//			float value = tab_value[x] = HAL_ADC_GetValue(&hadc1)*scale;
//			printf("Value : %f\r\n",value);
//			LCD_DrawPixel(x,(int) (159-value), BLUE);
//		}
//		LCD_FillScreen(BLACK);
		
		//exp�rience 3
//		while(flag_done ==0);
//		flag_done = 0;
//		printf("Changed to state : %i\r\n",current_state);
		
		
    /* USER CODE BEGIN 3 */		
		
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
* @brief Retargets the C library printf function to the USART.
* @param None
* @retval None
*/
PUTCHAR_PROTOTYPE
{
/* Place your implementation of fputc here */
/* e.g. write a character to the USART2 and Loop until the end
of transmission */
HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);
return ch;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) 
{
 if (((htim->Instance == TIM2) && (compteur !=0 ) && (compteur2 > 1) )   && (flag_state==1)) 
	{
//		HAL_ADC_Start(&hadc1);
//		HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_5);
		vx = 1/10; //constante
		positionYball = positionYball + 2.5;// vx*10;
		//if (vy !=0)	vy = vy + ay;
		vy = vy + ay;
		positionXball = positionXball + vy*10;
		
		//Did the user win?
		if (
			((positionYpig-positionYball)*(positionYpig-positionYball)
			+ (positionXpig-positionXball)*(positionXpig-positionXball)) <= 900
		) 	flag_done = 1;// Win
		else if (positionYball > 320 || positionXball > 240 || positionXball < 0) flag_done = 2;// Sort de l'�cran donc loose
		else if (positionYball >= 150 && positionYball <= 170 && positionXball <= 120) flag_done = 2;// Toucher le mur donc loose 
		else flag_done = -1; //rien ne s'est pass�
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
